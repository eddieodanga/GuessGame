
public class GameLauncer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 GuessGame game = new GuessGame();
 game.startGame();
	}

}
